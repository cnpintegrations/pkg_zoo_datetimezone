<?php

/**
 * @version     1.0.0
 * @package     mod_zoo_filtertime
 * @copyright   Copyright (C) 2013. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 * @author      Andreas Dionysopoulos & SIA OE <info@500web.gr> - http://www.500web.gr
 */

defined('_JEXEC') or die('Restricted access');

 
class modZoo_filtertimeHelper
{
    
}


?>